function suma(numero1, numero2) {
    console.log(numero1 + numero2)
}

let numero1 = parseFloat(prompt("Ingrese el valor del pantalón"))
let numero2 = parseFloat(prompt("Ingrese el valor de la blusa"))

suma(numero1, numero2)

function multiplicar(total, descuento) {
    console.log(total * descuento)
}

let descuento = 0.8
let total = parseFloat(prompt("Ingrese el total para aplicar el descuento"))

multiplicar(total, descuento)


let precio = parseFloat(prompt("Ingrese el total a pagar con el descuento"))
if(precio <= 5500) {
    console.log("Esto es muy barato, lo compro")
} else {
    console.log("Esto es muy caro, no lo compro")
}